export interface Picture {
    large:string;
    medium:string;
    thumbnail:string
}
