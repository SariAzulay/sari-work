import { Picture } from './picture';
import { Name } from './name';
export interface User {
    name:Name;
    phone:string;
    picture:Picture;

    
}