export interface Name {
    title:string;
    first:string;
    last:string;
}
