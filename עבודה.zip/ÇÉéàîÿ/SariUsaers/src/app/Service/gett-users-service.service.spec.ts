import { TestBed } from '@angular/core/testing';

import { GettUsersServiceService } from './gett-users-service.service';

describe('GettUsersServiceService', () => {
  let service: GettUsersServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GettUsersServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
