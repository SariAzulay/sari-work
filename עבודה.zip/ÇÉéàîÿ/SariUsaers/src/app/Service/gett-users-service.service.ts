import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { User } from '../Interfaces/user';
@Injectable({
  providedIn: 'root'
})
export class GettUsersServiceService {

  constructor(
      private http:HttpClient
  ) { }

  private url="https://randomuser.me/";

  getUsers():Observable<any>
  {
    return this.http.get(`${this.url}api/?results=3`);
  }
  

}
