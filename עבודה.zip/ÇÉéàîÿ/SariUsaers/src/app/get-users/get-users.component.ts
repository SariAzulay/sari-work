import { GettUsersServiceService } from '../Service/gett-users-service.service';
import { Component, OnInit } from '@angular/core';
import { NEVER, Observable } from 'rxjs';
import { User } from '../Interfaces/user';
import { tap } from 'rxjs/operators';
@Component({
  selector: 'app-get-users',
  templateUrl: './get-users.component.html',
  styleUrls: ['./get-users.component.css']
})
export class GetUsersComponent implements OnInit {

    name="name:";
    phone="phone:";
    img="image:";
   
    listUser2$:User[]=[];
  constructor(private ServiceUsers:GettUsersServiceService) {  }

  ngOnInit():void {
       this.getAll()
  }
    getAll()
    {
          this.ServiceUsers.getUsers().pipe(
        
         
        tap(result=>this.listUser2$=result.results)
        
     ).subscribe();
    }

  }

