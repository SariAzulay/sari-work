﻿using System;

namespace ConsoleApp1
{
    public class GFG
    {
        static int digSum(int n)
        {
            if (n == 0)
                return 0;

            return (n % 9 == 0) ? 9 : (n % 9);
        }

        static int repeatedNumberSum(int n, int x)
        {
            int sum = x * digSum(n);
            return digSum(sum);
        }

        public static void Main()
        {
            int n = 24, x = 4;
            Console.Write(repeatedNumberSum(n, x));
        }
    }
}
