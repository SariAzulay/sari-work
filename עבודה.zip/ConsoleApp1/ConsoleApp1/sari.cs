﻿using System;

namespace ConsoleApp1
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    namespace ConsoleApp2
    {
        class sari
        {
            //public static void merge(int []arr, int l, int m, int r)//mergesort call merge
            //   {
            //       int i, j, k;
            //       int n1 = m - l + 1;
            //       int n2 = r - m;
            //       int[] L = new int[n1];
            //        int []R=new int[n2];
            //       for (i = 0; i < n1; i++)
            //           L[i] = arr[l + i];
            //       for (j = 0; j < n2; j++)
            //           R[j] = arr[m + 1 + j];   
            //       i = 0;
            //       j = 0; 
            //       k = l; 
            //       while (i < n1 && j < n2)
            //       {
            //           if (L[i] <= R[j])
            //           {
            //               arr[k] = L[i];
            //               i++;
            //           }
            //           else
            //           {
            //               arr[k] = R[j];
            //               j++;
            //           }
            //           k++;
            //       }
            //       while (i < n1)
            //       {
            //           arr[k] = L[i];
            //           i++;
            //           k++;
            //       }
            //       while (j < n2)
            //       {
            //           arr[k] = R[j];
            //           j++;
            //           k++;
            //       }
            //   }
            //   public static void mergeSort(int []arr, int l, int r)//If the array was not a fixed value I would use mergeSort
            //   {
            //       if (l < r)
            //       {
            //           int m = l + (r - l) / 2; 
            //           mergeSort(arr, l, m);
            //           mergeSort(arr, m + 1, r);

            //           merge(arr, l, m, r);
            //       }
            //   }

            public static string MinMaxSum(int[] arr)
            {
                if (arr.Length == 0)
                    return "0 0";
                long MinMax = 0;
                int max = 0;
                int min = 0;
                for (int i = 0; i < 5; i++)
                {
                    MinMax += arr[i];
                    if (i == 0)
                    {
                        max = arr[i];
                        min = arr[i];
                    }
                    else
                    {
                        if (arr[i] > max)
                            max = arr[i];
                        else
                        {
                            if (arr[i] < min)
                                min = arr[i];
                        }
                    }
                }
                return (MinMax - max).ToString() + " " + (MinMax - min).ToString();

            }

            //}
            //public static int SuperDigit(string n, int k)
            //{
            //           if(n.Length==1)
            //              return int.Parse(n);
            //        int sum = 0;
            //        for (int i = 0; i < n.Length; i++)
            //        {
            //            sum += int.Parse(n.Substring(i, 1));
            //        }
            //        if (k != 0)
            //        {
            //            sum = sum * k;
            //            k = 0;
            //        }
            //    return SuperDigit( n = sum.ToString(),0);

            //}
            static void Main(string[] args)
            {
                // SuperDigit
                //int k = 4;
                //string s = "985";
                //Console.WriteLine(SuperDigit(s, k));

                //MinMax

                int[] arr = { 1, 3, 5, 7, 9 };
                Console.WriteLine(MinMaxSum(arr));

            }

        }
    }

}
